package com.bt3.service;

import com.bt3.dto.request.AccountRegisterRequest;
import com.bt3.dto.response.AccountRegisterResponse;

/**
 * Interface định nghĩa hợp đồng (contract) cho các nghiệp vụ quản lý tài khoản eKYC.
 *
 * <p>Lớp này đóng vai trò là Service Layer trong mô hình MVC 3 lớp,
 * tách biệt logic nghiệp vụ khỏi Controller và Repository.
 * Mọi thay đổi về business logic chỉ cần sửa ở phần implementation.</p>
 *
 * @author ABC Bank - eKYC Team
 * @version 1.0
 * @see com.bt3.service.impl.AccountServiceImpl
 */
public interface AccountService {

    /**
     * Xử lý nghiệp vụ đăng ký mở tài khoản cơ bản theo SRS FR-01.
     *
     * <p>Luồng xử lý:
     * <ol>
     *   <li>Kiểm tra trùng lặp dữ liệu (phone, email, citizenId)</li>
     *   <li>Sinh số tài khoản duy nhất</li>
     *   <li>Tạo hồ sơ tài khoản mới với trạng thái PENDING</li>
     *   <li>Lưu vào database và trả về thông tin tài khoản</li>
     * </ol>
     * </p>
     *
     * @param request DTO chứa thông tin đăng ký đã được validate
     * @return {@link AccountRegisterResponse} gồm accountId, accountNumber, status
     * @throws com.bt3.exception.DuplicateAccountException nếu phone/email/citizenId đã tồn tại
     */
    AccountRegisterResponse register(AccountRegisterRequest request);
}
