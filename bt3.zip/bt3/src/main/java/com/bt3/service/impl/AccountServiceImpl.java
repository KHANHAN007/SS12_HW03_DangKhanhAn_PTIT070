package com.bt3.service.impl;

import com.bt3.dto.request.AccountRegisterRequest;
import com.bt3.dto.response.AccountRegisterResponse;
import com.bt3.entity.Account;
import com.bt3.enums.AccountStatus;
import com.bt3.exception.DuplicateAccountException;
import com.bt3.repository.AccountRepository;
import com.bt3.service.AccountService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Triển khai nghiệp vụ đăng ký tài khoản eKYC của {@link AccountService}.
 *
 * <p>Lớp này thực hiện toàn bộ logic nghiệp vụ của bước FR-01 trong SRS:
 * kiểm tra trùng lặp dữ liệu, sinh số tài khoản, tạo hồ sơ và lưu vào database.
 * Mọi thao tác ghi được bọc trong transaction để đảm bảo tính toàn vẹn dữ liệu.</p>
 *
 * @author ABC Bank - eKYC Team
 * @version 1.0
 */
@Service
@RequiredArgsConstructor
public class AccountServiceImpl implements AccountService {

    /** Repository thao tác với bảng accounts trong database. */
    private final AccountRepository accountRepository;

    /**
     * Xử lý đăng ký mở tài khoản cơ bản theo SRS FR-01.
     *
     * <p>Các bước xử lý:
     * <ol>
     *   <li>Kiểm tra số điện thoại đã đăng ký chưa</li>
     *   <li>Kiểm tra email đã được sử dụng chưa</li>
     *   <li>Kiểm tra số CCCD đã tồn tại trong hệ thống chưa</li>
     *   <li>Sinh số tài khoản mới theo định dạng "ACC" + timestamp</li>
     *   <li>Tạo và lưu entity Account với trạng thái PENDING</li>
     *   <li>Map entity sang DTO response để trả về</li>
     * </ol>
     * </p>
     *
     * @param request DTO đã được validate chứa thông tin đăng ký
     * @return response gồm accountId, accountNumber và trạng thái PENDING
     * @throws DuplicateAccountException nếu phone, email hoặc CCCD đã tồn tại
     */
    @Override
    @Transactional
    public AccountRegisterResponse register(AccountRegisterRequest request) {

        // ---- Bước 1: Kiểm tra trùng lặp số điện thoại (SRS FR-01 Alt 4a) ----
        if (accountRepository.existsByPhone(request.getPhone())) {
            throw new DuplicateAccountException(
                "Số điện thoại '" + request.getPhone() + "' đã được đăng ký tài khoản. "
                + "Vui lòng đăng nhập hoặc sử dụng số điện thoại khác."
            );
        }

        // ---- Bước 2: Kiểm tra trùng lặp email ----
        if (accountRepository.existsByEmail(request.getEmail())) {
            throw new DuplicateAccountException(
                "Email '" + request.getEmail() + "' đã được sử dụng. "
                + "Vui lòng sử dụng địa chỉ email khác."
            );
        }

        // ---- Bước 3: Kiểm tra trùng lặp số CCCD (SRS FR-03 Alt 4a) ----
        if (accountRepository.existsByCitizenId(request.getCitizenId())) {
            throw new DuplicateAccountException(
                "Số CCCD '" + request.getCitizenId() + "' đã được đăng ký tài khoản tại ABC Bank. "
                + "Vui lòng liên hệ bộ phận hỗ trợ để khôi phục tài khoản."
            );
        }

        // ---- Bước 4: Sinh số tài khoản duy nhất theo định dạng ACC + timestamp ----
        String accountNumber = generateAccountNumber();

        // ---- Bước 5: Xây dựng entity Account mới với trạng thái PENDING ----
        Account newAccount = Account.builder()
            .fullName(request.getFullName())
            .phone(request.getPhone())
            .email(request.getEmail())
            .citizenId(request.getCitizenId())
            .accountNumber(accountNumber)
            .status(AccountStatus.PENDING) // Luôn bắt đầu với PENDING theo SRS
            .build();

        // ---- Bước 6: Lưu hồ sơ vào database ----
        Account savedAccount = accountRepository.save(newAccount);

        // ---- Bước 7: Map entity sang DTO response và trả về ----
        return AccountRegisterResponse.builder()
            .accountId(savedAccount.getId())
            .accountNumber(savedAccount.getAccountNumber())
            .status(savedAccount.getStatus())
            .build();
    }

    /**
     * Sinh số tài khoản duy nhất theo định dạng {@code ACC} + timestamp millisecond.
     *
     * <p>Ví dụ: {@code ACC1720000000000}
     * Trong môi trường production, nên thay bằng sequence từ database
     * hoặc thuật toán sinh số tài khoản theo chuẩn ngân hàng.</p>
     *
     * @return chuỗi số tài khoản duy nhất
     */
    private String generateAccountNumber() {
        // Sử dụng timestamp millisecond để đảm bảo tính duy nhất
        return "ACC" + System.currentTimeMillis();
    }
}
