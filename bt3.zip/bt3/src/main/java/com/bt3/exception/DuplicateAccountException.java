package com.bt3.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Exception ném ra khi thông tin đăng ký tài khoản bị trùng lặp trong hệ thống.
 *
 * <p>Được sử dụng trong các trường hợp theo SRS:
 * <ul>
 *   <li>FR-01 Alt 4a: Số điện thoại đã tồn tại trên hệ thống</li>
 *   <li>FR-03 Alt 4a: Số CCCD đã tồn tại trong cơ sở dữ liệu</li>
 *   <li>Email đã được đăng ký trước đó</li>
 * </ul>
 * </p>
 *
 * @author ABC Bank - eKYC Team
 * @version 1.0
 */
@ResponseStatus(HttpStatus.CONFLICT)
public class DuplicateAccountException extends RuntimeException {

    /**
     * Tạo exception với thông báo lỗi cụ thể.
     *
     * @param message mô tả trường dữ liệu bị trùng lặp
     */
    public DuplicateAccountException(String message) {
        super(message);
    }
}
