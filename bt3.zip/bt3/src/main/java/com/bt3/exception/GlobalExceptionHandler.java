package com.bt3.exception;

import com.bt3.dto.response.ApiResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.HashMap;
import java.util.Map;

/**
 * Global Exception Handler xử lý tập trung toàn bộ ngoại lệ của ứng dụng.
 *
 * <p>Sử dụng {@code @RestControllerAdvice} để bắt và xử lý các exception
 * phát sinh từ tất cả các Controller, trả về response JSON chuẩn hóa
 * theo định dạng {@link ApiResponse}.</p>
 *
 * <p>Các loại exception được xử lý:
 * <ul>
 *   <li>{@link MethodArgumentNotValidException} - lỗi validation dữ liệu đầu vào</li>
 *   <li>{@link DuplicateAccountException} - trùng lặp dữ liệu đăng ký</li>
 *   <li>{@link Exception} - fallback cho các lỗi không xác định</li>
 * </ul>
 * </p>
 *
 * @author ABC Bank - eKYC Team
 * @version 1.0
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    /**
     * Xử lý lỗi validation khi dữ liệu request không hợp lệ.
     *
     * <p>Bắt tất cả các lỗi từ {@code @Valid} hoặc {@code @Validated},
     * tổng hợp thành map field → message để trả về cho client.</p>
     *
     * @param ex exception chứa danh sách lỗi validation
     * @return ResponseEntity 400 Bad Request với danh sách lỗi từng field
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiResponse<Map<String, String>>> handleValidationErrors(
            MethodArgumentNotValidException ex) {

        // Thu thập tất cả lỗi theo từng field
        Map<String, String> errors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach(error -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            errors.put(fieldName, errorMessage);
        });

        // Trả về response lỗi cùng danh sách field bị lỗi
        ApiResponse<Map<String, String>> response = ApiResponse.<Map<String, String>>builder()
            .success(false)
            .message("Dữ liệu đầu vào không hợp lệ")
            .data(errors)
            .build();

        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
    }

    /**
     * Xử lý lỗi khi dữ liệu đăng ký bị trùng lặp trong hệ thống.
     *
     * <p>Tương ứng với SRS FR-01 Alt 4a (số điện thoại đã tồn tại)
     * và FR-03 Alt 4a (số CCCD đã tồn tại).</p>
     *
     * @param ex exception chứa thông tin trường bị trùng
     * @return ResponseEntity 409 Conflict
     */
    @ExceptionHandler(DuplicateAccountException.class)
    public ResponseEntity<ApiResponse<Void>> handleDuplicateAccount(
            DuplicateAccountException ex) {

        return ResponseEntity
            .status(HttpStatus.CONFLICT)
            .body(ApiResponse.error(ex.getMessage()));
    }

    /**
     * Xử lý tất cả các exception không mong muốn còn lại (fallback handler).
     *
     * <p>Tránh lộ stack trace ra ngoài, thay bằng thông báo lỗi thân thiện.</p>
     *
     * @param ex exception chung chưa được xử lý
     * @return ResponseEntity 500 Internal Server Error
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<Void>> handleGeneralException(Exception ex) {
        // Log lỗi nội bộ (production nên dùng Logger)
        return ResponseEntity
            .status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body(ApiResponse.error("Hệ thống xảy ra lỗi. Vui lòng thử lại sau."));
    }
}
