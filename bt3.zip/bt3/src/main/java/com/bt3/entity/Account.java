package com.bt3.entity;

import com.bt3.enums.AccountStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Entity đại diện cho hồ sơ tài khoản khách hàng trong hệ thống eKYC ABC Bank.
 *
 * <p>Bảng {@code accounts} lưu trữ thông tin đăng ký ban đầu của khách hàng theo FR-01.
 * Sau khi tạo, trạng thái mặc định là {@link AccountStatus#PENDING} và sẽ chuyển sang
 * {@link AccountStatus#ACTIVE} sau khi hoàn thành đầy đủ các bước eKYC (FR-06).</p>
 *
 * @author ABC Bank - eKYC Team
 * @version 1.0
 */
@Entity
@Table(
    name = "accounts",
    uniqueConstraints = {
        // Mỗi số điện thoại chỉ được đăng ký 1 tài khoản
        @UniqueConstraint(name = "uk_accounts_phone", columnNames = "phone"),
        // Mỗi email chỉ được sử dụng 1 lần
        @UniqueConstraint(name = "uk_accounts_email", columnNames = "email"),
        // Mỗi số CCCD chỉ được đăng ký 1 lần (theo SRS FR-03)
        @UniqueConstraint(name = "uk_accounts_citizen_id", columnNames = "citizen_id")
    }
)
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Account {

    /**
     * Khóa chính tự tăng - ID nội bộ của hồ sơ.
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    /**
     * Số tài khoản duy nhất do hệ thống sinh ra (định dạng: ACC + timestamp).
     */
    @Column(name = "account_number", nullable = false, unique = true, length = 20)
    private String accountNumber;

    /**
     * Họ và tên đầy đủ của khách hàng.
     */
    @Column(name = "full_name", nullable = false, length = 100)
    private String fullName;

    /**
     * Số điện thoại liên hệ (10 chữ số, bắt đầu bằng 0).
     */
    @Column(name = "phone", nullable = false, length = 15)
    private String phone;

    /**
     * Địa chỉ email của khách hàng.
     */
    @Column(name = "email", nullable = false, length = 100)
    private String email;

    /**
     * Số Căn cước công dân 12 chữ số (theo quy định FR-02 SRS).
     */
    @Column(name = "citizen_id", nullable = false, length = 12)
    private String citizenId;

    /**
     * Trạng thái hiện tại của tài khoản.
     * Mặc định là PENDING khi mới tạo.
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    @Builder.Default
    private AccountStatus status = AccountStatus.PENDING;

    /**
     * Thời điểm tạo hồ sơ (tự động set khi insert).
     */
    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    /**
     * Thời điểm cập nhật hồ sơ lần cuối.
     */
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    /**
     * Tự động set thời gian trước khi persist vào database.
     */
    @PrePersist
    protected void onCreate() {
        // Gán thời gian tạo và cập nhật bằng thời điểm hiện tại
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
    }

    /**
     * Tự động cập nhật thời gian trước khi update vào database.
     */
    @PreUpdate
    protected void onUpdate() {
        // Cập nhật thời gian sửa đổi mỗi khi entity được cập nhật
        this.updatedAt = LocalDateTime.now();
    }
}
