package com.bt3.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;

import java.lang.annotation.*;

/**
 * Annotation custom validation kiểm tra định dạng số Căn cước công dân (CCCD).
 *
 * <p>Theo quy định của FR-02 SRS ABC Bank, hệ thống chỉ chấp nhận CCCD 12 chữ số
 * (không phải CMND 9 số cũ). Annotation này có thể được đặt trên field hoặc parameter.</p>
 *
 * <p>Ví dụ sử dụng:
 * <pre>
 *   {@code @ValidCitizenId}
 *   private String citizenId;
 * </pre>
 * </p>
 *
 * @author ABC Bank - eKYC Team
 * @version 1.0
 * @see CitizenIdValidator
 */
@Documented
@Constraint(validatedBy = CitizenIdValidator.class)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidCitizenId {

    /**
     * Thông báo lỗi mặc định khi validate không hợp lệ.
     *
     * @return thông báo lỗi
     */
    String message() default "Số CCCD phải gồm đúng 12 chữ số";

    /**
     * Nhóm validate (mặc định rỗng).
     *
     * @return mảng các nhóm
     */
    Class<?>[] groups() default {};

    /**
     * Payload bổ sung (mặc định rỗng).
     *
     * @return mảng các payload
     */
    Class<? extends Payload>[] payload() default {};
}
