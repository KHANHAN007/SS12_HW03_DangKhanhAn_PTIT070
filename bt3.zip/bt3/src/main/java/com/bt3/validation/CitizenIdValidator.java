package com.bt3.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

/**
 * Lớp triển khai logic kiểm tra hợp lệ cho annotation {@link ValidCitizenId}.
 *
 * <p>Theo yêu cầu SRS FR-02 của ABC Bank, số CCCD phải đáp ứng:
 * <ul>
 *   <li>Không được null hoặc rỗng</li>
 *   <li>Phải gồm đúng 12 ký tự số (0-9)</li>
 * </ul>
 * </p>
 *
 * @author ABC Bank - eKYC Team
 * @version 1.0
 */
public class CitizenIdValidator implements ConstraintValidator<ValidCitizenId, String> {

    /**
     * Pattern regex: đúng 12 chữ số từ 0-9.
     */
    private static final String CITIZEN_ID_PATTERN = "^[0-9]{12}$";

    /**
     * Khởi tạo validator (không cần cấu hình thêm).
     *
     * @param constraintAnnotation annotation được gắn trên field
     */
    @Override
    public void initialize(ValidCitizenId constraintAnnotation) {
        // Không cần khởi tạo thêm tham số
    }

    /**
     * Kiểm tra tính hợp lệ của số Căn cước công dân.
     *
     * <p>Quy tắc: đúng 12 chữ số, không chứa ký tự chữ cái hay ký tự đặc biệt.</p>
     *
     * @param citizenId  giá trị số CCCD cần kiểm tra
     * @param context    ngữ cảnh validate
     * @return {@code true} nếu hợp lệ, {@code false} nếu không hợp lệ
     */
    @Override
    public boolean isValid(String citizenId, ConstraintValidatorContext context) {
        // Cho phép null để kết hợp với @NotBlank xử lý trường hợp null riêng
        if (citizenId == null) {
            return true;
        }
        // Kiểm tra đúng 12 chữ số theo pattern regex
        return citizenId.matches(CITIZEN_ID_PATTERN);
    }
}
