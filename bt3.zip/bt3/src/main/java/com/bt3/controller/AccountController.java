package com.bt3.controller;

import com.bt3.dto.request.AccountRegisterRequest;
import com.bt3.dto.response.AccountRegisterResponse;
import com.bt3.dto.response.ApiResponse;
import com.bt3.service.AccountService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Controller xử lý các request liên quan đến đăng ký và quản lý tài khoản eKYC.
 *
 * <p>Tầng Controller có trách nhiệm:
 * <ul>
 *   <li>Nhận request HTTP từ Mobile Client</li>
 *   <li>Trigger validation dữ liệu đầu vào ({@code @Valid})</li>
 *   <li>Ủy thác xử lý nghiệp vụ cho {@link AccountService}</li>
 *   <li>Đóng gói kết quả vào {@link ApiResponse} và trả về HTTP response</li>
 * </ul>
 * </p>
 *
 * <p>Base URL: {@code /api/accounts}</p>
 *
 * @author ABC Bank - eKYC Team
 * @version 1.0
 */
@RestController
@RequestMapping("/api/accounts")
@RequiredArgsConstructor
public class AccountController {

    /** Service xử lý nghiệp vụ tài khoản. */
    private final AccountService accountService;

    /**
     * API đăng ký mở tài khoản cơ bản eKYC.
     *
     * <p><b>Endpoint:</b> {@code POST /api/accounts/register}</p>
     *
     * <p><b>Request Body (JSON):</b>
     * <pre>
     * {
     *   "fullName": "Nguyen Van A",
     *   "phone": "0901234567",
     *   "email": "nguyenvana@email.com",
     *   "citizenId": "012345678901"
     * }
     * </pre>
     * </p>
     *
     * <p><b>Response Body (JSON) - 201 Created:</b>
     * <pre>
     * {
     *   "success": true,
     *   "message": "Đăng ký tài khoản thành công. Trạng thái: PENDING",
     *   "data": {
     *     "accountId": 1,
     *     "accountNumber": "ACC1720000000000",
     *     "status": "PENDING"
     *   },
     *   "timestamp": "2024-07-03T10:00:00"
     * }
     * </pre>
     * </p>
     *
     * <p><b>HTTP Status Codes:</b>
     * <ul>
     *   <li>201 Created - đăng ký thành công</li>
     *   <li>400 Bad Request - dữ liệu đầu vào không hợp lệ</li>
     *   <li>409 Conflict - phone/email/CCCD đã tồn tại</li>
     *   <li>500 Internal Server Error - lỗi hệ thống</li>
     * </ul>
     * </p>
     *
     * @param request DTO chứa thông tin đăng ký, được validate tự động
     * @return ResponseEntity 201 với thông tin tài khoản vừa tạo
     */
    @PostMapping("/register")
    public ResponseEntity<ApiResponse<AccountRegisterResponse>> register(
            @Valid @RequestBody AccountRegisterRequest request) {

        // Ủy thác xử lý nghiệp vụ cho Service Layer
        AccountRegisterResponse response = accountService.register(request);

        // Đóng gói kết quả vào response chuẩn và trả về HTTP 201 Created
        return ResponseEntity
            .status(HttpStatus.CREATED)
            .body(ApiResponse.success(
                "Đăng ký tài khoản thành công. Trạng thái: " + response.getStatus(),
                response
            ));
    }
}
