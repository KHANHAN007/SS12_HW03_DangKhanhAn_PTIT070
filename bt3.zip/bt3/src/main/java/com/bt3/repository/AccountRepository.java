package com.bt3.repository;

import com.bt3.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository cung cấp các thao tác CRUD và truy vấn tùy chỉnh cho {@link Account}.
 *
 * <p>Kế thừa {@link JpaRepository} để có sẵn các phương thức cơ bản như
 * {@code save()}, {@code findById()}, {@code delete()} v.v.
 * Ngoài ra, bổ sung các phương thức kiểm tra tính duy nhất phục vụ
 * business rule đăng ký tài khoản theo SRS FR-01 và FR-03.</p>
 *
 * @author ABC Bank - eKYC Team
 * @version 1.0
 */
@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {

    /**
     * Kiểm tra xem số điện thoại đã tồn tại trong hệ thống hay chưa.
     *
     * <p>Theo SRS FR-01 Alt 4a: nếu số điện thoại đã tồn tại,
     * hệ thống phải thông báo lỗi và gợi ý khách hàng đăng nhập.</p>
     *
     * @param phone số điện thoại cần kiểm tra
     * @return {@code true} nếu đã tồn tại, {@code false} nếu chưa
     */
    boolean existsByPhone(String phone);

    /**
     * Kiểm tra xem địa chỉ email đã tồn tại trong hệ thống hay chưa.
     *
     * @param email địa chỉ email cần kiểm tra
     * @return {@code true} nếu đã tồn tại, {@code false} nếu chưa
     */
    boolean existsByEmail(String email);

    /**
     * Kiểm tra xem số CCCD đã được đăng ký tài khoản hay chưa.
     *
     * <p>Theo SRS FR-03 Alt 4a: nếu số CCCD đã tồn tại,
     * hệ thống chuyển hướng sang luồng khôi phục tài khoản hiện hữu.</p>
     *
     * @param citizenId số CCCD 12 chữ số cần kiểm tra
     * @return {@code true} nếu đã tồn tại, {@code false} nếu chưa
     */
    boolean existsByCitizenId(String citizenId);
}
