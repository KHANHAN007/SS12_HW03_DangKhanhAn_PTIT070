package com.bt3.dto.response;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * Wrapper chuẩn hóa định dạng response API trả về cho client.
 *
 * <p>Tất cả các API trong hệ thống eKYC đều sử dụng lớp này để đảm bảo
 * cấu trúc JSON nhất quán, dễ parse tại phía client (Mobile App).</p>
 *
 * <p>Ví dụ response thành công:
 * <pre>
 * {
 *   "success": true,
 *   "message": "Đăng ký tài khoản thành công",
 *   "data": { "accountId": 1, "accountNumber": "ACC1720000000000", "status": "PENDING" },
 *   "timestamp": "2024-07-03T10:00:00"
 * }
 * </pre>
 * </p>
 *
 * @param <T> kiểu dữ liệu của trường {@code data}
 * @author ABC Bank - eKYC Team
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiResponse<T> {

    /**
     * Cờ cho biết request có thành công không.
     */
    private boolean success;

    /**
     * Thông báo mô tả kết quả (thành công hoặc lỗi).
     */
    private String message;

    /**
     * Dữ liệu trả về khi thành công (null khi có lỗi).
     */
    private T data;

    /**
     * Thời điểm xử lý response (ISO 8601).
     */
    @Builder.Default
    private LocalDateTime timestamp = LocalDateTime.now();

    /**
     * Tạo nhanh một response thành công có kèm dữ liệu.
     *
     * @param message thông báo thành công
     * @param data    dữ liệu trả về
     * @param <T>     kiểu dữ liệu
     * @return ApiResponse với success=true
     */
    public static <T> ApiResponse<T> success(String message, T data) {
        return ApiResponse.<T>builder()
            .success(true)
            .message(message)
            .data(data)
            .timestamp(LocalDateTime.now())
            .build();
    }

    /**
     * Tạo nhanh một response lỗi không có dữ liệu đi kèm.
     *
     * @param message thông báo lỗi
     * @param <T>     kiểu dữ liệu
     * @return ApiResponse với success=false
     */
    public static <T> ApiResponse<T> error(String message) {
        return ApiResponse.<T>builder()
            .success(false)
            .message(message)
            .timestamp(LocalDateTime.now())
            .build();
    }
}
