package com.bt3.dto.response;

import com.bt3.enums.AccountStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO trả về kết quả đăng ký tài khoản eKYC cho client.
 *
 * <p>Theo SRS yêu cầu, sau khi đăng ký thành công endpoint trả về:
 * <ul>
 *   <li>{@code accountId} - ID nội bộ của hồ sơ tài khoản</li>
 *   <li>{@code accountNumber} - Số tài khoản do hệ thống sinh ra</li>
 *   <li>{@code status} - Trạng thái hiện tại (luôn là PENDING sau đăng ký)</li>
 * </ul>
 * </p>
 *
 * @author ABC Bank - eKYC Team
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountRegisterResponse {

    /**
     * ID nội bộ của hồ sơ tài khoản trong hệ thống.
     */
    private Long accountId;

    /**
     * Số tài khoản thanh toán do hệ thống tự sinh.
     * Định dạng: ACC + timestamp millisecond (ví dụ: ACC1720000000000).
     */
    private String accountNumber;

    /**
     * Trạng thái tài khoản sau khi đăng ký.
     * Mặc định là {@link AccountStatus#PENDING} - chờ xác thực eKYC.
     */
    private AccountStatus status;
}
