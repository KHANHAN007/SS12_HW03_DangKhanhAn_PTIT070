package com.bt3.dto.request;

import com.bt3.validation.ValidCitizenId;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * DTO nhận dữ liệu đầu vào từ request đăng ký tài khoản eKYC.
 *
 * <p>Tương ứng với endpoint {@code POST /api/accounts/register} theo SRS FR-01.
 * Tất cả các trường đều bắt buộc và được validate theo quy định nghiệp vụ.</p>
 *
 * <p>Ràng buộc:
 * <ul>
 *   <li>{@code fullName} - không được trống</li>
 *   <li>{@code phone} - không được trống, định dạng số điện thoại VN 10 số</li>
 *   <li>{@code email} - phải đúng định dạng email</li>
 *   <li>{@code citizenId} - đúng 12 chữ số (custom validator)</li>
 * </ul>
 * </p>
 *
 * @author ABC Bank - eKYC Team
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountRegisterRequest {

    /**
     * Họ và tên đầy đủ của khách hàng.
     * Không được để trống hoặc chỉ có khoảng trắng.
     */
    @NotBlank(message = "Họ và tên không được để trống")
    private String fullName;

    /**
     * Số điện thoại liên hệ.
     * Phải là số điện thoại Việt Nam hợp lệ (10 chữ số, bắt đầu bằng 0).
     */
    @NotBlank(message = "Số điện thoại không được để trống")
    @Pattern(
        regexp = "^0[0-9]{9}$",
        message = "Số điện thoại phải gồm 10 chữ số và bắt đầu bằng 0"
    )
    private String phone;

    /**
     * Địa chỉ email của khách hàng.
     * Phải đúng định dạng email chuẩn.
     */
    @NotBlank(message = "Email không được để trống")
    @Email(message = "Email không đúng định dạng")
    private String email;

    /**
     * Số Căn cước công dân 12 chữ số.
     * Theo SRS FR-02: chỉ chấp nhận CCCD 12 số, không chấp nhận CMND 9 số cũ.
     */
    @NotBlank(message = "Số CCCD không được để trống")
    @ValidCitizenId
    private String citizenId;
}
