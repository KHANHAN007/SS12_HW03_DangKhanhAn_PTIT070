package com.bt3.enums;

/**
 * Enum định nghĩa các trạng thái của tài khoản trong hệ thống eKYC.
 *
 * <p>Dựa theo SRS FR-01 và FR-06 của ABC Bank:
 * <ul>
 *   <li>{@link #PENDING} - Tài khoản vừa được tạo, chờ xác thực eKYC hoàn tất</li>
 *   <li>{@link #ACTIVE} - Tài khoản đã được kích hoạt sau khi qua đủ các bước eKYC</li>
 * </ul>
 * </p>
 *
 * @author ABC Bank - eKYC Team
 * @version 1.0
 */
public enum AccountStatus {

    /**
     * Trạng thái chờ xử lý - tài khoản mới tạo, chưa hoàn thành eKYC.
     */
    PENDING,

    /**
     * Trạng thái kích hoạt - tài khoản đã xác thực và sử dụng được.
     */
    ACTIVE
}
